library(testthat)
library(DescObs)

test_check("DescObs")
